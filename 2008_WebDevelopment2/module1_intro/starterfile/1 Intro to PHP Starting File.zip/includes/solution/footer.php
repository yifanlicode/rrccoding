		<footer>
			<div id="social">
				<ul>
					<li><a href="http://www.facebook.com/RedRiverCollege">
						<img src="images/facebookicon.jpg" alt="" /></a></li>
					<li><a href="http://www.twitter.com/rrc">
						<img src="images/twittericon.jpg" alt="" /></a></li>
					<li><a href="http://www.youtube.com/redrivercollege">
						<img src="images/youtubeicon.jpg" alt="" /></a></li>
				</ul>
			</div>
		</footer>
	</div>
</body>
</html>